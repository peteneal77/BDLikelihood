README - Analysis (R Covid Paper, Section 4)
--------------------------------------------

This is a Readme file for the sub-folder Analysis of the analysis of Abakiliki data in: "Fast likelihood calculations for emerging epidemics" Ball and Neal (2022), Section 4. 

Abak_grid_E_90 - Calculation of the log-likelihood using the Exact GSE likelihood for 100*100 grid points for alpha and mu with T=90
Abak_grid_E_46b - Calculation of the log-likelihood using the Exact GSE likelihood for 100*100 grid points for alpha and mu with T=46.99

Abak_T90_E.png - Likelihood contour plot (Exact GSE) for T=90
Abak_T90_B.png - Likelihood contour plot (Birth-Death) for T=90
Abak_T90_E.png - Likelihood contour plot (Approximate Birth-Death) for T=90
Abak_T46b_E.png - Likelihood contour plot (Exact GSE) for T=46.99